<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboard;
use App\Http\Controllers\Admin\AngkatanController;
use App\Http\Controllers\Admin\AlumniController as AdminAlumni;
use App\Http\Controllers\Admin\LaporanController;
use App\Http\Controllers\Admin\ActivityLogController;

/*
|--------------------------------------------------------------------------
| Public Routes
|--------------------------------------------------------------------------
*/
Route::get('/', [LandingController::class, 'index'])->name('landing.index');

/*
|--------------------------------------------------------------------------
| Guest Routes (Login & Register)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login']);

    Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register', [RegisterController::class, 'register']);

    // 🔎 CEK NISN (AJAX / REALTIME)
    Route::post('/cek-nisn', [RegisterController::class, 'cekNisn'])->name('cek.nisn');
});

/*
|--------------------------------------------------------------------------
| Authenticated Routes
|--------------------------------------------------------------------------
*/
Route::middleware(['auth'])->group(function () {
    Route::get('/direktori', [LandingController::class, 'direktori'])->name('landing.direktori');
    Route::get('/profil-alumni/{alumni}', [LandingController::class, 'profilAlumni'])->name('landing.profil');
    Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
});

/*
|--------------------------------------------------------------------------
| Admin Routes (Role: admin)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        // Dashboard
        Route::get('/dashboard', [AdminDashboard::class, 'index'])->name('dashboard');

        // Kelola Angkatan
        Route::resource('angkatan', AngkatanController::class);

        // Kelola Alumni
        Route::prefix('alumni')->name('alumni.')->group(function () {
            Route::get('/', [AdminAlumni::class, 'index'])->name('index');
            Route::get('/{alumni}', [AdminAlumni::class, 'show'])->name('show');

            Route::patch('/{alumni}/verify', [AdminAlumni::class, 'verify'])->name('verify');
            Route::patch('/{alumni}/reset-password', [AdminAlumni::class, 'resetPassword'])->name('reset-password');

            Route::delete('/{alumni}', [AdminAlumni::class, 'destroy'])->name('destroy');
        });

        // Laporan
        Route::get('/laporan', [LaporanController::class, 'index'])->name('laporan.index');
        Route::get('/laporan/angkatan/{angkatan}', [LaporanController::class, 'angkatan'])->name('laporan.angkatan');

        // Activity Logs
        Route::get('/logs', [ActivityLogController::class, 'index'])->name('logs.index');
        Route::delete('/logs/{log}', [ActivityLogController::class, 'destroy'])->name('logs.destroy');
        Route::delete('/logs-clear-all', [ActivityLogController::class, 'clearAll'])->name('logs.clearAll');
    });

/*
|--------------------------------------------------------------------------
| Alumni Routes (Role: alumni)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'alumni'])
    ->prefix('alumni')
    ->name('alumni.')
    ->group(function () {

        Route::get('/dashboard', [App\Http\Controllers\Alumni\DashboardController::class, 'index'])->name('dashboard');

        // Profile Management
        Route::get('/profile/edit', [App\Http\Controllers\Alumni\ProfileController::class, 'edit'])->name('profile.edit');
        Route::put('/profile/update', [App\Http\Controllers\Alumni\ProfileController::class, 'update'])->name('profile.update');
        Route::put('/profile/password', [App\Http\Controllers\Alumni\ProfileController::class, 'updatePassword'])->name('profile.updatePassword');

        // Direktori Alumni
        Route::get('/direktori', [App\Http\Controllers\Alumni\DirektoriController::class, 'index'])->name('direktori');
        Route::get('/direktori/{alumni}', [App\Http\Controllers\Alumni\DirektoriController::class, 'show'])->name('direktori.show');
    });
