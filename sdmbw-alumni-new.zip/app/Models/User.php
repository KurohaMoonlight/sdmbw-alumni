<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    /**
     * Field yang boleh diisi mass assignment
     * Menambahkan 'is_active' dan 'nisn' agar sinkron dengan Register & Verifikasi
     */
    protected $fillable = [
        'username',
        'password',
        'role',
        'nisn',         // Tambahkan ini untuk fitur reset password
        'is_active',    // Tambahkan ini untuk sistem verifikasi gembok login
        'last_login_at',
    ];

    /**
     * Field yang disembunyikan saat serialize
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Cast tipe data
     * Menambahkan 'is_active' sebagai boolean agar true/false terbaca benar
     */
    protected function casts(): array
    {
        return [
            'last_login_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean', // Memastikan 0/1 di DB dikonversi jadi false/true
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Relasi Antar Tabel
    |--------------------------------------------------------------------------
    */

    /**
     * Relasi: User punya 1 profil alumni (jika role = alumni)
     */
    public function alumni(): HasOne
    {
        return $this->hasOne(Alumni::class);
    }

    /**
     * Relasi: User (admin) punya banyak log
     */
    public function adminLogs(): HasMany
    {
        return $this->hasMany(AdminLog::class, 'admin_id');
    }

    /*
    |--------------------------------------------------------------------------
    | Helper Functions (Logika Bisnis)
    |--------------------------------------------------------------------------
    */

    /**
     * Check apakah user adalah admin
     */
    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    /**
     * Check apakah user adalah alumni
     */
    public function isAlumni(): bool
    {
        return $this->role === 'alumni';
    }

    /**
     * Check apakah akun sudah diaktifkan/diverifikasi
     */
    public function isActive(): bool
    {
        return $this->is_active === true;
    }

    /*
    |--------------------------------------------------------------------------
    | Scopes & Observers
    |--------------------------------------------------------------------------
    */

    public function scopeAdmin($query)
    {
        return $query->where('role', 'admin');
    }

    public function scopeAlumni($query)
    {
        return $query->where('role', 'alumni');
    }

    /**
     * Update waktu login terakhir
     */
    public function updateLastLogin(): void
    {
        $this->update(['last_login_at' => now()]);
    }
}
