<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Alumni extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'alumni';

    protected $fillable = [
        'user_id',
        'nisn',
        'nama_lengkap',
        'angkatan_id',
        'tahun_lulus',
        'alamat',
        'no_hp',
        'email',
        'pendidikan_lanjutan',
        'pekerjaan',
        'harapan',
        'status_verifikasi',
        'is_profile_complete',
    ];

    protected $casts = [
        'tahun_lulus' => 'integer',
        'is_profile_complete' => 'boolean',
    ];

    /**
     * Set default nilai atribut
     */
    protected $attributes = [
        'status_verifikasi' => 'pending',
        'is_profile_complete' => false,
    ];

    /*
    |--------------------------------------------------------------------------
    | Relasi Antar Tabel
    |--------------------------------------------------------------------------
    */

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function angkatan(): BelongsTo
    {
        return $this->belongsTo(Angkatan::class, 'angkatan_id');
    }

    /*
    |--------------------------------------------------------------------------
    | Query Scopes
    |--------------------------------------------------------------------------
    */

    public function scopeVerified($query)
    {
        return $query->where('status_verifikasi', 'verified');
    }

    public function scopePending($query)
    {
        return $query->where('status_verifikasi', 'pending');
    }

    public function scopeRejected($query)
    {
        return $query->where('status_verifikasi', 'rejected');
    }

    public function scopeProfileComplete($query)
    {
        return $query->where('is_profile_complete', true);
    }

    /*
    |--------------------------------------------------------------------------
    | Helper Logic
    |--------------------------------------------------------------------------
    */

    /**
     * Mengecek kelengkapan data untuk indikator persentase profil
     */
    public function isDataComplete(): bool
    {
        // Pastikan field utama tidak null atau string kosong
        return !empty(trim($this->alamat))
            && !empty(trim($this->no_hp))
            && (!empty(trim($this->pendidikan_lanjutan)) || !empty(trim($this->pekerjaan)));
    }
}
