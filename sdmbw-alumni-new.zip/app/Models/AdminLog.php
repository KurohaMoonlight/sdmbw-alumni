<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AdminLog extends Model
{
    /**
     * Nama tabel
     */
    protected $table = 'admin_logs';

    /**
     * Field yang boleh diisi
     */
    protected $fillable = [
        'admin_id',
        'action',
        'target_type',
        'target_id',
        'description',
    ];

    /**
     * Relasi: Log dibuat oleh admin (user dengan role admin)
     */
    public function admin(): BelongsTo
    {
        return $this->belongsTo(User::class, 'admin_id');
    }

    /**
     * Helper: Catat log admin
     */
    public static function log(int $adminId, string $action, ?string $targetType = null, ?int $targetId = null, ?string $description = null): void
    {
        self::create([
            'admin_id' => $adminId,
            'action' => $action,
            'target_type' => $targetType,
            'target_id' => $targetId,
            'description' => $description,
        ]);
    }
}
