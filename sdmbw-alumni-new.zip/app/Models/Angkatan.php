<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Angkatan extends Model
{
    /**
     * Nama tabel di database
     */
    protected $table = 'angkatan';

    /**
     * Field yang boleh diisi mass assignment
     */
    protected $fillable = [
        'nama_angkatan',
        'tahun_ajaran',
        'status',
    ];

    /**
     * Relasi: Satu angkatan punya banyak alumni
     */
    public function alumni(): HasMany
    {
        return $this->hasMany(Alumni::class, 'angkatan_id');
    }

    /**
     * Scope: Hanya angkatan yang sudah LULUS
     */
    public function scopeLulus($query)
    {
        return $query->where('status', 'LULUS');
    }

    /**
     * Scope: Hanya angkatan AKTIF
     */
    public function scopeAktif($query)
    {
        return $query->where('status', 'AKTIF');
    }

    /**
     * Scope: Hanya angkatan BELUM LULUS
     */
    public function scopeBelumLulus($query)
    {
        return $query->where('status', 'BELUM_LULUS');
    }
}
