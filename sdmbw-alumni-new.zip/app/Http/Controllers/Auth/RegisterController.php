<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Alumni;
use App\Models\Angkatan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class RegisterController extends Controller
{
    /**
     * Tampilkan form registrasi
     */
    public function showRegistrationForm()
    {
        // Ambil angkatan yang statusnya LULUS (untuk SD biasanya sudah ditentukan)
        $angkatans = Angkatan::where('status', 'LULUS')
            ->orderBy('id', 'asc')
            ->get();

        return view('auth.register', compact('angkatans'));
    }

    /**
     * Proses registrasi
     */
    public function register(Request $request)
    {
        // 1. Validasi input dengan pesan custom
        $validated = $request->validate([
            'nisn' => ['required', 'digits:10', 'unique:alumni,nisn'], // ✅ FIX FINAL
            'nama_lengkap' => ['required', 'string', 'max:255'],
            'angkatan_id' => ['required', 'exists:angkatan,id'], // ✅ FIX FINAL
            'tahun_lulus' => ['required', 'integer', 'min:2010', 'max:' . (date('Y') + 1)],
            'username' => ['required', 'string', 'alpha_num', 'min:4', 'max:255', 'unique:users,username'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
        ], [
            'nisn.required' => 'NISN wajib diisi.',
            'nisn.digits' => 'NISN harus terdiri dari tepat 10 digit angka.',
            'nisn.unique' => 'NISN ini sudah terdaftar sebelumnya.',
            'nama_lengkap.required' => 'Nama lengkap sesuai ijazah wajib diisi.',
            'username.unique' => 'Username sudah digunakan oleh orang lain.',
            'password.confirmed' => 'Konfirmasi password tidak cocok.',
        ]);

        // 2. Double Check: Pastikan angkatan valid
        $angkatan = Angkatan::findOrFail($validated['angkatan_id']);
        if ($angkatan->status !== 'LULUS') {
            return back()->withErrors([
                'angkatan_id' => 'Angkatan yang Anda pilih belum diizinkan untuk mendaftar.'
            ])->withInput();
        }

        try {
            DB::beginTransaction();

            // 3. Buat Data User (Login)
            // Tambahkan is_active = false agar akun terkunci sementara
            $user = User::create([
                'username'  => strtolower($validated['username']),
                'password'  => Hash::make($validated['password']),
                'role'      => 'alumni',
                'is_active' => false, // PENTING: Gembok akun baru
                'nisn'      => $validated['nisn'],
            ]);

            // 4. Buat Profil Alumni
            Alumni::create([
                'user_id'             => $user->id,
                'nisn'                => $validated['nisn'],
                'nama_lengkap'        => strip_tags($validated['nama_lengkap']),
                'angkatan_id'         => $validated['angkatan_id'],
                'tahun_lulus'         => $validated['tahun_lulus'],
                'status_verifikasi'   => 'pending',
                'is_profile_complete' => false,
            ]);

            DB::commit();

            return redirect()
                ->route('login')
                ->with('success', 'Registrasi Berhasil! Akun Anda sedang menunggu verifikasi admin SD. Mohon tunggu beberapa saat.');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Kesalahan Registrasi Alumni: ' . $e->getMessage());

            return back()
                ->withErrors(['error' => 'Gagal memproses pendaftaran. Silakan coba lagi.'])
                ->withInput();
        }
    }
}
