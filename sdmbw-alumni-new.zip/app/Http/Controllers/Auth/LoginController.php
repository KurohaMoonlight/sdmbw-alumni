<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        if (Auth::check()) {
            return $this->redirectBasedOnRole();
        }

        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        // 1. Coba proses login terlebih dahulu
        if (Auth::attempt($credentials, $request->filled('remember'))) {

            $user = Auth::user();

            // 2. CEK STATUS VERIFIKASI (Gembok Keamanan)
            // Pastikan di database kamu ada kolom 'is_active' (0 = pending, 1 = aktif)
            if ($user->role === 'alumni' && $user->is_active == 0) {
                Auth::logout(); // Keluarkan kembali jika belum aktif

                return back()->withErrors([
                    'username' => 'Akun Anda belum diverifikasi oleh Admin SD. Harap tunggu atau hubungi Admin via WA.',
                ])->onlyInput('username');
            }

            // 3. Jika lolos (Admin atau Alumni Aktif), lanjutkan proses
            $request->session()->regenerate();

            // Update waktu login terakhir
            DB::table('users')
                ->where('id', $user->id)
                ->update(['last_login_at' => now()]);

            return $this->redirectBasedOnRole();
        }

        // Jika username/password salah
        return back()->withErrors([
            'username' => 'Username atau password salah.',
        ])->onlyInput('username');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('landing.index')->with('success', 'Berhasil logout.');
    }

    private function redirectBasedOnRole()
    {
        $user = Auth::user();

        if ($user->role === 'admin') {
            return redirect()->route('admin.dashboard');
        }

        if ($user->role === 'alumni') {
            return redirect()->route('alumni.dashboard');
        }

        Auth::logout();
        return redirect()->route('login')->withErrors([
            'username' => 'Role akun tidak valid.'
        ]);
    }
}
