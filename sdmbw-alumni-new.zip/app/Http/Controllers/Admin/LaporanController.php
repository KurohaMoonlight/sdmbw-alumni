<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Alumni;
use App\Models\Angkatan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LaporanController extends Controller
{
    /**
     * Tampilkan halaman laporan
     */
    public function index(Request $request)
    {
        // Statistik Umum - MENGGUNAKAN WHERE MANUAL AGAR TIDAK ERROR
        $stats = [
            'total_alumni'         => Alumni::count(),
            'alumni_verified'      => Alumni::where('status_verifikasi', 'verified')->count(),
            'alumni_pending'       => Alumni::where('status_verifikasi', 'pending')->count(),
            'alumni_rejected'      => Alumni::where('status_verifikasi', 'rejected')->count(),
            'profil_lengkap'       => Alumni::where('is_profile_complete', true)->count(),
            'profil_belum_lengkap' => Alumni::where('is_profile_complete', false)->count(),
        ];

        // Statistik per Angkatan - URUT DARI ANGKATAN 1 KE ATAS
        $angkatanStats = Angkatan::withCount([
            'alumni',
            'alumni as verified_count' => function($query) {
                $query->where('status_verifikasi', 'verified');
            },
            'alumni as pending_count' => function($query) {
                $query->where('status_verifikasi', 'pending');
            },
            'alumni as complete_count' => function($query) {
                $query->where('is_profile_complete', true);
            }
        ])
        ->orderBy('id', 'asc')
        ->get();

        // Alumni berdasarkan pendidikan lanjutan
        $pendidikanStats = Alumni::select('pendidikan_lanjutan', DB::raw('count(*) as total'))
            ->whereNotNull('pendidikan_lanjutan')
            ->where('pendidikan_lanjutan', '!=', '')
            ->groupBy('pendidikan_lanjutan')
            ->orderBy('total', 'desc')
            ->take(10)
            ->get();

        // Alumni berdasarkan pekerjaan
        $pekerjaanStats = Alumni::select('pekerjaan', DB::raw('count(*) as total'))
            ->whereNotNull('pekerjaan')
            ->where('pekerjaan', '!=', '')
            ->groupBy('pekerjaan')
            ->orderBy('total', 'desc')
            ->take(10)
            ->get();

        return view('admin.laporan.index', compact(
            'stats',
            'angkatanStats',
            'pendidikanStats',
            'pekerjaanStats'
        ));
    }

    /**
     * Laporan per angkatan
     */
    public function angkatan(Request $request, $angkatanId)
    {
        $angkatan = Angkatan::findOrFail($angkatanId);

        $alumni = Alumni::with('user')
            ->where('angkatan_id', $angkatanId)
            ->when($request->filled('status'), function($query) use ($request) {
                $query->where('status_verifikasi', $request->status);
            })
            ->orderBy('nama_lengkap')
            ->get();

        $stats = [
            'total'    => $alumni->count(),
            'verified' => $alumni->where('status_verifikasi', 'verified')->count(),
            'pending'  => $alumni->where('status_verifikasi', 'pending')->count(),
            'rejected' => $alumni->where('status_verifikasi', 'rejected')->count(),
            'lengkap'  => $alumni->where('is_profile_complete', true)->count(),
        ];

        return view('admin.laporan.angkatan', compact('angkatan', 'alumni', 'stats'));
    }
}
