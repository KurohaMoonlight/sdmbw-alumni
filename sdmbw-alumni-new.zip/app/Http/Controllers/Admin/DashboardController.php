<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Angkatan;
use App\Models\Alumni;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Tampilkan dashboard admin dengan statistik lengkap
     */
    public function index()
    {
        // 1. Statistik Utama (Menggunakan Scope & State-based query)
        $stats = [
            'total_alumni'         => Alumni::count(),
            'alumni_verified'      => Alumni::verified()->count(),
            'alumni_pending'       => Alumni::pending()->count(),
            'total_angkatan'       => Angkatan::whereIn('status', ['AKTIF', 'LULUS'])->count(),
            'angkatan_aktif'       => Angkatan::where('status', 'AKTIF')->count(),
            'angkatan_lulus'       => Angkatan::where('status', 'LULUS')->count(),
            'angkatan_belum_lulus' => Angkatan::where('status', 'BELUM LULUS')->count(),
            'profil_lengkap'       => Alumni::where('is_profile_complete', true)->count(),
        ];

        // 2. Ambil 5 Alumni Terbaru (Urutan berdasarkan pendaftaran akun)
        $recentAlumni = Alumni::with(['user', 'angkatan'])
            ->latest()
            ->take(5)
            ->get();

        // 3. Statistik Angkatan (Menggunakan withCount untuk efisiensi) - Hanya AKTIF dan LULUS
        $angkatanStats = Angkatan::whereIn('status', ['AKTIF', 'LULUS'])
            ->withCount('alumni')
            ->orderBy('id', 'asc')
            ->get();

        // 4. Alumni yang baru saja update profil
        // Menambahkan Eager Loading 'user' agar bisa menampilkan nama di View
        $recentUpdates = Alumni::with(['user', 'angkatan'])
            ->where('is_profile_complete', true)
            ->latest('updated_at') // Fokus pada waktu perubahan data terakhir
            ->take(5)
            ->get();

        return view('admin.dashboard', compact(
            'stats',
            'recentAlumni',
            'angkatanStats',
            'recentUpdates'
        ));
    }
}
