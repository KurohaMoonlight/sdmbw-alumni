<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Alumni;
use App\Models\Angkatan;
use App\Models\AdminLog;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class AlumniController extends Controller
{
    /**
     * Tampilkan daftar alumni dengan filter lengkap
     */
    public function index(Request $request)
    {
        // Eager load 'user' dan 'angkatan' untuk performa
        $query = Alumni::with(['user', 'angkatan']);

        // Filter status
        if ($request->filled('status')) {
            $query->where('status_verifikasi', $request->status);
        }

        // Filter angkatan
        if ($request->filled('angkatan_id')) {
            $query->where('angkatan_id', $request->angkatan_id);
        }

        // Filter profil
        if ($request->filled('complete')) {
            $query->where('is_profile_complete', $request->complete == '1' ? true : false);
        }

        // Search Nama atau NISN
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('nama_lengkap', 'like', "%{$search}%")
                    ->orWhere('nisn', 'like', "%{$search}%");
            });
        }

        // Pagination 20 item per halaman
        $alumnis = $query->latest()->paginate(20);

        // Ambil data angkatan untuk dropdown filter
        $angkatans = Angkatan::orderBy('id', 'asc')->get();

        return view('admin.alumni.index', compact('alumnis', 'angkatans'));
    }

    /**
     * Verifikasi status alumni (Verified / Rejected / Pending)
     */
    public function verify(Request $request, Alumni $alumni)
    {
        // Default ke 'verified' jika tombol langsung diklik tanpa input status khusus
        $status = $request->input('status', 'verified');

        DB::beginTransaction();
        try {
            // 1. Update status di tabel Alumni
            $alumni->update([
                'status_verifikasi' => $status,
            ]);

            // 2. Update is_active di tabel Users (Hanya aktif jika verified)
            if ($alumni->user) {
                $alumni->user->update([
                    'is_active' => ($status === 'verified') ? 1 : 0
                ]);
            }

            // 3. Log aktivitas admin
            AdminLog::log(
                Auth::id(),
                'verify_alumni',
                'alumni',
                $alumni->id,
                "Mengubah status verifikasi {$alumni->nama_lengkap} ke {$status}"
            );

            DB::commit();

            $message = $status === 'verified' ? 'Alumni berhasil diverifikasi dan akun diaktifkan.' : 'Status verifikasi berhasil diperbarui.';
            return back()->with('success', $message);

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Terjadi kesalahan saat verifikasi: ' . $e->getMessage());
        }
    }

    /**
     * Reset password alumni kembali ke NISN
     */
    public function resetPassword(Alumni $alumni)
    {
        // Cek apakah NISN ada
        if (!$alumni->nisn) {
            return back()->with('error', 'Gagal reset! Data NISN tidak ditemukan.');
        }

        DB::beginTransaction();
        try {
            // Cek apakah user terkait ada
            if ($alumni->user) {
                $alumni->user->update([
                    'password' => Hash::make($alumni->nisn),
                ]);

                // Log aktivitas
                AdminLog::log(
                    Auth::id(),
                    'reset_password',
                    'alumni',
                    $alumni->id,
                    "Reset password alumni: {$alumni->nama_lengkap} menjadi NISN"
                );

                DB::commit();
                return back()->with('success', "Password {$alumni->nama_lengkap} berhasil direset ke NISN ({$alumni->nisn}).");
            }

            // Jika data alumni ada tapi akun user tidak ditemukan
            return back()->with('error', 'Akun user tidak ditemukan untuk alumni ini.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Gagal reset password: ' . $e->getMessage());
        }
    }

    /**
     * Hapus Alumni Secara Permanen (Force Delete)
     */
    public function destroy($id)
    {
        // Menggunakan withTrashed() agar bisa menghapus yang sudah soft-delete (jika ada)
        $alumni = Alumni::withTrashed()->findOrFail($id);
        $namaAlumni = $alumni->nama_lengkap;

        DB::beginTransaction();
        try {
            // 1. Hapus akun User terkait jika ada
            if ($alumni->user_id) {
                User::where('id', $alumni->user_id)->delete();
            }

            // 2. Hapus data Alumni secara permanen
            $alumni->forceDelete();

            // 3. Log aktivitas
            AdminLog::log(
                Auth::id(),
                'delete_alumni',
                'alumni',
                null, // ID null karena data sudah dihapus
                "Menghapus permanen alumni: {$namaAlumni}"
            );

            DB::commit();
            return back()->with('success', 'Data alumni dan akun pengguna berhasil dihapus permanen!');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Gagal menghapus data: ' . $e->getMessage());
        }
    }
}
