<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminLog;
use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    /**
     * Tampilkan activity logs
     */
    public function index(Request $request)
    {
        $query = AdminLog::with('admin');

        // Filter berdasarkan action
        if ($request->filled('action')) {
            $query->where('action', $request->action);
        }

        // Filter berdasarkan tanggal
        if ($request->filled('date')) {
            $query->whereDate('created_at', $request->date);
        }

        // Search
        if ($request->filled('search')) {
            $query->where('description', 'like', '%' . $request->search . '%');
        }

        $logs = $query->latest()->paginate(30);

        // Daftar action untuk filter
        $actions = AdminLog::distinct()->pluck('action');

        return view('admin.logs.index', compact('logs', 'actions'));
    }

    /**
     * Hapus satu log
     */
    public function destroy(AdminLog $log)
    {
        $log->delete();

        return back()->with('success', 'Log berhasil dihapus!');
    }

    /**
     * Hapus semua log
     */
    public function clearAll()
    {
        AdminLog::truncate();

        return back()->with('success', 'Semua activity logs berhasil dihapus!');
    }
}
