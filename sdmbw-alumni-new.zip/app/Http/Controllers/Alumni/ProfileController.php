<?php

namespace App\Http\Controllers\Alumni;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class ProfileController extends Controller
{
    /**
     * Tampilkan form edit profil
     */
    public function edit(): View|RedirectResponse
    {
        /** @var User $user */
        $user = Auth::user();
        $alumni = $user->alumni;

        if (!$alumni) {
            return redirect()->route('login')->with('error', 'Data alumni tidak ditemukan.');
        }

        $alumni->load('angkatan');

        return view('alumni.profile.edit', compact('alumni'));
    }

    /**
     * Update profil alumni
     */
    public function update(Request $request): RedirectResponse
    {
        /** @var User $user */
        $user = Auth::user();
        $alumni = $user->alumni;

        if (!$alumni) {
            return redirect()->route('login')->with('error', 'Data alumni tidak ditemukan.');
        }

        $validated = $request->validate([
            'alamat'              => 'required|string',
            'no_hp'               => 'required|numeric|digits_between:10,14',
            'email'               => 'nullable|email|max:255',
            'pendidikan_lanjutan' => 'required|string|max:255',
            'pekerjaan'           => 'nullable|string|max:255',
            'harapan'             => 'nullable|string',
        ], [
            'alamat.required'              => 'Alamat wajib diisi',
            'no_hp.required'               => 'Nomor HP wajib diisi',
            'no_hp.numeric'                => 'Nomor HP harus berupa angka',
            'no_hp.digits_between'         => 'Nomor HP harus terdiri dari 10 sampai 14 angka',
            'pendidikan_lanjutan.required' => 'Pendidikan lanjutan wajib diisi',
        ]);

        $validated['is_profile_complete'] = true;

        $alumni->update($validated);

        return redirect()
            ->route('alumni.dashboard')
            ->with('success', 'Profil berhasil diperbarui!');
    }

    /**
     * Ganti password
     */
    public function updatePassword(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'current_password' => 'required',
            'password'         => 'required|min:6|confirmed',
        ], [
            'current_password.required' => 'Password lama wajib diisi',
            'password.required'         => 'Password baru wajib diisi',
            'password.min'              => 'Password minimal 6 karakter',
            'password.confirmed'        => 'Konfirmasi password tidak cocok',
        ]);

        /** @var User $user */
        $user = Auth::user();

        // Cek password lama
        if (!Hash::check($validated['current_password'], $user->password)) {
            return back()->withErrors(['current_password' => 'Password lama tidak sesuai']);
        }

        // Update password
        $user->update([
            'password' => Hash::make($validated['password'])
        ]);

        return back()->with('success', 'Password berhasil diubah!');
    }
}
