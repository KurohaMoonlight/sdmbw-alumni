<?php

namespace App\Http\Controllers\Alumni;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Alumni;
use App\Models\Angkatan;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    /**
     * Display dashboard alumni
     */
    public function index()
    {
        $alumni = Auth::user()->alumni;

        return view('alumni.dashboard', compact('alumni'));
    }

    /**
     * Display direktori alumni (di dalam dashboard)
     */
    public function direktori(Request $request)
    {
        $query = Alumni::with(['angkatan', 'user'])
            ->whereHas('user', function($q) {
                $q->where('status_verifikasi', 'terverifikasi');
            })
            ->where('id', '!=', Auth::user()->alumni->id); // Jangan tampilkan profil sendiri

        // Filter angkatan
        if ($request->filled('angkatan_id')) {
            $query->where('angkatan_id', $request->angkatan_id);
        }

        // Search
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('nama_lengkap', 'like', '%' . $request->search . '%')
                  ->orWhere('nisn', 'like', '%' . $request->search . '%');
            });
        }

        $alumnis = $query->orderBy('nama_lengkap', 'asc')->paginate(12);
        $angkatans = Angkatan::orderBy('tahun_ajaran', 'desc')->get();

        return view('alumni.direktori', compact('alumnis', 'angkatans'));
    }

    /**
     * Display profil alumni lain (di dalam dashboard)
     */
    public function showProfil($id)
    {
        $alumni = Alumni::with(['angkatan', 'user'])->findOrFail($id);

        // Cek apakah alumni terverifikasi
        if ($alumni->user->status_verifikasi !== 'terverifikasi') {
            return redirect()->route('alumni.direktori')
                ->with('error', 'Profil alumni tidak dapat diakses.');
        }

        return view('alumni.profil', compact('alumni'));
    }
}
