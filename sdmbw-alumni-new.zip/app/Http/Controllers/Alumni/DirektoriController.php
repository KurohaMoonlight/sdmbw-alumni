<?php

namespace App\Http\Controllers\Alumni;

use App\Http\Controllers\Controller;
use App\Models\Alumni;
use App\Models\Angkatan;
use Illuminate\Http\Request;

class DirektoriController extends Controller
{
    public function index(Request $request)
    {
        $query = Alumni::with('angkatan');

        // Filter Pencarian Nama
        if ($request->filled('search')) {
            $query->where('nama_lengkap', 'like', '%' . $request->search . '%');
        }

        // Filter Angkatan
        if ($request->filled('angkatan')) {
            $query->where('angkatan_id', $request->angkatan);
        }

        // Pagination 12 data per halaman
        $alumni = $query->latest()->paginate(12)->withQueryString();

        // Perbaikan Urutan: Menggunakan tahun_ajaran agar urut 1, 2, dst.
        $angkatan = Angkatan::orderBy('tahun_ajaran', 'asc')->get();

        return view('alumni.direktori.index', compact('alumni', 'angkatan'));
    }

    public function show($id)
    {
        $alumni = Alumni::with('angkatan')->findOrFail($id);
        return view('alumni.direktori.show', compact('alumni'));
    }
}
