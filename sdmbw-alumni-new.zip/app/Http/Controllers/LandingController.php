<?php

namespace App\Http\Controllers;

use App\Models\Alumni;
use App\Models\Angkatan;
use Illuminate\Http\Request;

class LandingController extends Controller
{
    public function index()
    {
        $stats = [
            'total_alumni' => Alumni::verified()->count(),
            'total_angkatan' => Angkatan::count(),
        ];

        return view('landing.index', compact('stats'));
    }

    public function direktori(Request $request)
    {
        $query = Alumni::with(['angkatan', 'user'])->verified();

        if ($request->filled('angkatan_id')) {
            $query->where('angkatan_id', $request->angkatan_id);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('nama_lengkap', 'like', "%{$search}%")
                  ->orWhere('nisn', 'like', "%{$search}%");
            });
        }

        $alumnis = $query->latest()->paginate(12)->withQueryString();
        $angkatans = Angkatan::orderBy('tahun_ajaran', 'desc')->get();

        return view('landing.direktori', compact('alumnis', 'angkatans'));
    }

    public function profilAlumni(Alumni $alumni)
    {
        // Gunakan loadMissing agar tidak double query jika data sudah ada
        $alumni->loadMissing(['angkatan', 'user']);

        // Pastikan hanya yang verified yang bisa diakses publik
        if ($alumni->status_verifikasi !== 'verified') {
            abort(404);
        }

        return view('landing.profil', compact('alumni'));
    }
}
