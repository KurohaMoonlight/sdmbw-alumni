@extends('layouts.admin')

@section('title', 'Edit Angkatan')
@section('page-title', 'Edit Angkatan')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-white">
                <h6 class="mb-0">
                    <i class="bi bi-pencil"></i> Form Edit Angkatan
                </h6>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.angkatan.update', $angkatan) }}" method="POST">
                    @csrf
                    @method('PUT')

                    <div class="mb-3">
                        <label for="nama_angkatan" class="form-label">
                            Nama Angkatan <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               class="form-control @error('nama_angkatan') is-invalid @enderror"
                               id="nama_angkatan"
                               name="nama_angkatan"
                               value="{{ old('nama_angkatan', $angkatan->nama_angkatan) }}"
                               placeholder="Contoh: Angkatan 11"
                               required>
                        @error('nama_angkatan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="tahun_ajaran" class="form-label">
                            Tahun Ajaran <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               class="form-control @error('tahun_ajaran') is-invalid @enderror"
                               id="tahun_ajaran"
                               name="tahun_ajaran"
                               value="{{ old('tahun_ajaran', $angkatan->tahun_ajaran) }}"
                               placeholder="Contoh: 2026-2027"
                               required>
                        @error('tahun_ajaran')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">
                            Status <span class="text-danger">*</span>
                        </label>
                        <select class="form-select @error('status') is-invalid @enderror"
                                id="status"
                                name="status"
                                required>
                            <option value="">-- Pilih Status --</option>
                            <option value="BELUM_LULUS"
                                    {{ old('status', $angkatan->status) == 'BELUM_LULUS' ? 'selected' : '' }}>
                                BELUM LULUS
                            </option>
                            <option value="LULUS"
                                    {{ old('status', $angkatan->status) == 'LULUS' ? 'selected' : '' }}>
                                LULUS
                            </option>
                        </select>
                        @error('status')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <small class="form-text text-muted">
                            Ubah status ke <strong>LULUS</strong> jika angkatan sudah lulus
                        </small>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between">
                        <a href="{{ route('admin.angkatan.index') }}" class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> Update Angkatan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="alert alert-warning">
            <h6><i class="bi bi-exclamation-triangle"></i> Perhatian</h6>
            <hr>
            <ul class="mb-0">
                <li>Hati-hati mengubah status angkatan</li>
                <li>Jika diubah ke <strong>BELUM LULUS</strong>, alumni tidak bisa login</li>
                <li>Jika diubah ke <strong>LULUS</strong>, alumni bisa login</li>
            </ul>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <h6>Info Angkatan</h6>
                <hr>
                <table class="table table-sm">
                    <tr>
                        <td><strong>ID:</strong></td>
                        <td>{{ $angkatan->id }}</td>
                    </tr>
                    <tr>
                        <td><strong>Dibuat:</strong></td>
                        <td>{{ $angkatan->created_at->format('d M Y H:i') }}</td>
                    </tr>
                    <tr>
                        <td><strong>Update Terakhir:</strong></td>
                        <td>{{ $angkatan->updated_at->format('d M Y H:i') }}</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
