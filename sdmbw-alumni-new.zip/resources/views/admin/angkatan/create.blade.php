@extends('layouts.admin')

@section('title', 'Tambah Angkatan')
@section('page-title', 'Tambah Angkatan Baru')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-white">
                <h6 class="mb-0">
                    <i class="bi bi-plus-circle"></i> Form Tambah Angkatan
                </h6>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.angkatan.store') }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <label for="nama_angkatan" class="form-label">
                            Nama Angkatan <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               class="form-control @error('nama_angkatan') is-invalid @enderror"
                               id="nama_angkatan"
                               name="nama_angkatan"
                               value="{{ old('nama_angkatan', 'Angkatan ' . $nextNumber) }}"
                               placeholder="Angkatan {{ $nextNumber }}"
                               readonly
                               required>
                        @error('nama_angkatan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <small class="form-text text-muted">
                            Nama angkatan otomatis: <strong>Angkatan {{ $nextNumber }}</strong>
                        </small>
                    </div>

                    <div class="mb-3">
                        <label for="tahun_ajaran" class="form-label">
                            Tahun Ajaran <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               class="form-control @error('tahun_ajaran') is-invalid @enderror"
                               id="tahun_ajaran"
                               name="tahun_ajaran"
                               value="{{ old('tahun_ajaran') }}"
                               placeholder="Contoh: 2026-2027"
                               required>
                        @error('tahun_ajaran')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <small class="form-text text-muted">
                            Format: YYYY-YYYY (contoh: 2026-2027)
                        </small>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">
                            Status <span class="text-danger">*</span>
                        </label>
                        <select class="form-select @error('status') is-invalid @enderror"
                                id="status"
                                name="status"
                                required>
                            <option value="">-- Pilih Status --</option>
                            <option value="AKTIF" {{ old('status') == 'AKTIF' ? 'selected' : '' }}>
                                AKTIF
                            </option>
                            <option value="LULUS" {{ old('status') == 'LULUS' ? 'selected' : '' }}>
                                LULUS
                            </option>
                        </select>
                        @error('status')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <small class="form-text text-muted">
                            Pilih <strong>AKTIF</strong> untuk angkatan yang sedang berjalan, atau <strong>LULUS</strong> untuk angkatan yang sudah tamat
                        </small>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between">
                        <a href="{{ route('admin.angkatan.index') }}" class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> Simpan Angkatan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="alert alert-info">
            <h6><i class="bi bi-info-circle"></i> Panduan</h6>
            <hr>
            <ul class="mb-0">
                <li>Isi <strong>Nama Angkatan</strong> sesuai format</li>
                <li>Isi <strong>Tahun Ajaran</strong> dengan format YYYY-YYYY</li>
                <li>Pilih status <strong>AKTIF</strong> untuk angkatan berjalan</li>
                <li>Pilih status <strong>LULUS</strong> untuk angkatan tamat</li>
                <li>Status bisa diubah nanti sesuai kebutuhan</li>
            </ul>
        </div>
    </div>
</div>
@endsection
