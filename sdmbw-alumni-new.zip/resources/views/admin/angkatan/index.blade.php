@extends('layouts.admin')

@section('title', 'Kelola Angkatan')
@section('page-title', 'Kelola Angkatan')

@section('content')
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h6 class="mb-0">
            <i class="bi bi-calendar-event"></i> Daftar Angkatan
        </h6>
        <a href="{{ route('admin.angkatan.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle"></i> Tambah Angkatan
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th>Nama Angkatan</th>
                        <th>Tahun Ajaran</th>
                        <th>Status</th>
                        <th class="text-center">Jumlah Alumni</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($angkatans as $index => $angkatan)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>
                            <strong>{{ $angkatan->nama_angkatan }}</strong>
                        </td>
                        <td>{{ $angkatan->tahun_ajaran }}</td>
                        <td>
                            @if($angkatan->status == 'LULUS')
                                <span class="badge rounded-pill bg-light-success text-success border border-success px-3">LULUS</span>
                            @elseif($angkatan->status == 'AKTIF')
                                <span class="badge rounded-pill bg-light-warning text-warning border border-warning px-3">AKTIF</span>
                            @endif
                        </td>
                        <td class="text-center">
                            <span class="badge bg-primary">{{ $angkatan->alumni_count }} Alumni</span>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="{{ route('admin.angkatan.edit', $angkatan) }}"
                                   class="btn btn-warning"
                                   title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>

                                @if($angkatan->alumni_count == 0)
                                <form action="{{ route('admin.angkatan.destroy', $angkatan) }}"
                                      method="POST"
                                      class="d-inline"
                                      onsubmit="return confirm('Yakin ingin menghapus angkatan ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                                @else
                                <button class="btn btn-secondary" disabled title="Tidak bisa dihapus (ada alumni)">
                                    <i class="bi bi-trash"></i>
                                </button>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="bi bi-inbox" style="font-size: 48px;"></i>
                            <p class="mt-2">Belum ada data angkatan</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="mt-3">
    <div class="alert alert-info">
        <i class="bi bi-info-circle"></i>
        <strong>Info:</strong>
        <ul class="mb-0 mt-2">
            <li>Angkatan dengan status <strong>LULUS</strong> bisa dibuatkan akun alumni.</li>
            <li>Angkatan dengan status <strong>BELUM LULUS</strong> belum bisa login ke sistem.</li>
            <li>Angkatan yang sudah memiliki alumni tidak bisa dihapus.</li>
        </ul>
    </div>
</div>
@endsection
