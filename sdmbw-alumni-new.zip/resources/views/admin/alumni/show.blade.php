@extends('layouts.admin')

@section('title', 'Detail Alumni')
@section('page-title', 'Detail Alumni')

@section('content')
<div class="row">
    <div class="col-md-8">
        <!-- Data Pribadi -->
        <div class="card mb-3">
            <div class="card-header bg-white">
                <h6 class="mb-0">
                    <i class="bi bi-person-badge"></i> Data Pribadi
                </h6>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">NISN</div>
                    <div class="col-md-8"><strong>{{ $alumni->nisn }}</strong></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Nama Lengkap</div>
                    <div class="col-md-8"><strong>{{ $alumni->nama_lengkap }}</strong></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Angkatan</div>
                    <div class="col-md-8">
                        <span class="badge bg-primary">
                            {{ $alumni->angkatan->nama_angkatan ?? '-' }}
                        </span>
                        <small class="text-muted">({{ $alumni->angkatan->tahun_ajaran ?? '-' }})</small>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Tahun Lulus</div>
                    <div class="col-md-8"><strong>{{ $alumni->tahun_lulus }}</strong></div>
                </div>
                <hr>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Alamat</div>
                    <div class="col-md-8">{{ $alumni->alamat ?? '-' }}</div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">No. HP</div>
                    <div class="col-md-8">{{ $alumni->no_hp ?? '-' }}</div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Email</div>
                    <div class="col-md-8">{{ $alumni->email ?? '-' }}</div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Pendidikan Lanjutan</div>
                    <div class="col-md-8">{{ $alumni->pendidikan_lanjutan ?? '-' }}</div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Pekerjaan</div>
                    <div class="col-md-8">{{ $alumni->pekerjaan ?? '-' }}</div>
                </div>
                <div class="row">
                    <div class="col-md-4 text-muted">Harapan & Pesan</div>
                    <div class="col-md-8">{{ $alumni->harapan ?? '-' }}</div>
                </div>
            </div>
        </div>

        <!-- Info Akun -->
        <div class="card">
            <div class="card-header bg-white">
                <h6 class="mb-0">
                    <i class="bi bi-person-circle"></i> Informasi Akun
                </h6>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Username</div>
                    <div class="col-md-8"><strong>{{ $alumni->user->username ?? '-' }}</strong></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Role</div>
                    <div class="col-md-8">
                        <span class="badge bg-info">{{ $alumni->user->role ?? '-' }}</span>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Terdaftar</div>
                    <div class="col-md-8">{{ $alumni->created_at->format('d M Y H:i') }}</div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 text-muted">Update Terakhir</div>
                    <div class="col-md-8">{{ $alumni->updated_at->format('d M Y H:i') }}</div>
                </div>
                @if($alumni->user->last_login_at)
                <div class="row">
                    <div class="col-md-4 text-muted">Login Terakhir</div>
                    <div class="col-md-8">{{ $alumni->user->last_login_at->format('d M Y H:i') }}</div>
                </div>
                @endif
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <!-- Status Card -->
        <div class="card mb-3">
            <div class="card-header bg-white">
                <h6 class="mb-0">
                    <i class="bi bi-info-circle"></i> Status
                </h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label">Status Verifikasi</label>
                    <div>
                        @if($alumni->status_verifikasi == 'verified')
                            <span class="badge bg-success">
                                <i class="bi bi-check-circle"></i> Verified
                            </span>
                        @elseif($alumni->status_verifikasi == 'pending')
                            <span class="badge bg-warning text-dark">
                                <i class="bi bi-clock"></i> Pending
                            </span>
                        @else
                            <span class="badge bg-danger">
                                <i class="bi bi-x-circle"></i> Rejected
                            </span>
                        @endif
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kelengkapan Profil</label>
                    <div>
                        @if($alumni->is_profile_complete)
                            <span class="badge bg-success">
                                <i class="bi bi-check-circle"></i> Lengkap
                            </span>
                        @else
                            <span class="badge bg-secondary">
                                <i class="bi bi-exclamation-circle"></i> Belum Lengkap
                            </span>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <!-- Aksi -->
        <div class="card">
            <div class="card-header bg-white">
                <h6 class="mb-0">
                    <i class="bi bi-gear"></i> Aksi
                </h6>
            </div>
            <div class="card-body">
                @if($alumni->status_verifikasi == 'pending')
                <!-- Verifikasi -->
                <form action="{{ route('admin.alumni.verify', $alumni) }}" method="POST" class="mb-2">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="status" value="verified">
                    <button type="submit" class="btn btn-success w-100" onclick="return confirm('Verifikasi alumni ini?')">
                        <i class="bi bi-check-circle"></i> Verifikasi Alumni
                    </button>
                </form>

                <form action="{{ route('admin.alumni.verify', $alumni) }}" method="POST" class="mb-2">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="status" value="rejected">
                    <button type="submit" class="btn btn-danger w-100" onclick="return confirm('Tolak alumni ini?')">
                        <i class="bi bi-x-circle"></i> Tolak Alumni
                    </button>
                </form>
                @endif

                <!-- Reset Password -->
                <form action="{{ route('admin.alumni.resetPassword', $alumni) }}" method="POST" class="mb-2">
                    @csrf
                    @method('PUT')
                    <button type="submit" class="btn btn-warning w-100" onclick="return confirm('Reset password ke NISN?')">
                        <i class="bi bi-key"></i> Reset Password
                    </button>
                </form>

                <!-- Hapus -->
                <form action="{{ route('admin.alumni.destroy', $alumni) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-outline-danger w-100" onclick="return confirm('Yakin ingin menghapus alumni ini?')">
                        <i class="bi bi-trash"></i> Hapus Alumni
                    </button>
                </form>

                <hr>

                <a href="{{ route('admin.alumni.index') }}" class="btn btn-secondary w-100">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</div>
@endsection
