@extends('layouts.admin')

@section('title', 'Kelola Alumni')
@section('page-title', 'Kelola Alumni')

@section('content')
<div class="card mb-3">
    <div class="card-body">
        <form action="{{ route('admin.alumni.index') }}" method="GET">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label small fw-bold">Status Verifikasi</label>
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="verified" {{ request('status') == 'verified' ? 'selected' : '' }}>Verified (Aktif)</option>
                        <option value="rejected" {{ request('status') == 'rejected' ? 'selected' : '' }}>Rejected</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold">Angkatan</label>
                    <select name="angkatan_id" class="form-select">
                        <option value="">Semua Angkatan</option>
                        @foreach($angkatans as $angkatan)
                            <option value="{{ $angkatan->id }}" {{ request('angkatan_id') == $angkatan->id ? 'selected' : '' }}>
                                {{ $angkatan->nama_angkatan }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label small fw-bold">Profil</label>
                    <select name="complete" class="form-select">
                        <option value="">Semua</option>
                        <option value="1" {{ request('complete') == '1' ? 'selected' : '' }}>Lengkap</option>
                        <option value="0" {{ request('complete') == '0' ? 'selected' : '' }}>Belum Lengkap</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold">Search</label>
                    <input type="text" name="search" class="form-control" placeholder="NISN atau Nama" value="{{ request('search') }}">
                </div>
                <div class="col-md-1 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white py-3">
        <h6 class="mb-0 fw-bold">
            <i class="bi bi-people text-primary me-2"></i> Daftar Alumni ({{ $alumnis->total() }})
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="5%">No</th>
                        <th>NISN</th>
                        <th>Nama Lengkap</th>
                        <th>Angkatan</th>
                        <th>Status Akun</th>
                        <th>Profil</th>
                        <th width="15%" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($alumnis as $index => $alumni)
                    <tr>
                        <td>{{ $alumnis->firstItem() + $index }}</td>
                        {{-- NISN dengan warna pink sesuai screenshot --}}
                        <td><code class="fw-bold" style="color: #d63384;">{{ $alumni->nisn }}</code></td>
                        <td>
                            <span class="fw-bold text-dark">{{ $alumni->nama_lengkap }}</span>
                            <br>
                            <small class="text-muted">
                                <i class="bi bi-person"></i> User: {{ $alumni->user->username ?? '-' }}
                            </small>
                        </td>
                        <td>
                            <span class="badge rounded-pill bg-light text-primary border border-primary">
                                {{ $alumni->angkatan->nama_angkatan ?? '-' }}
                            </span>
                        </td>
                        <td>
                            @if($alumni->status_verifikasi == 'verified')
                                <span class="badge bg-success"><i class="bi bi-patch-check"></i> Aktif</span>
                            @elseif($alumni->status_verifikasi == 'pending')
                                <span class="badge bg-warning text-dark"><i class="bi bi-hourglass-split"></i> Menunggu</span>
                            @else
                                <span class="badge bg-danger"><i class="bi bi-x-octagon"></i> Ditolak</span>
                            @endif
                        </td>
                        <td>
                            @if($alumni->is_profile_complete)
                                <span class="text-success small fw-bold"><i class="bi bi-check-all"></i> Lengkap</span>
                            @else
                                <span class="text-muted small"><i class="bi bi-dash-circle"></i> Belum</span>
                            @endif
                        </td>
                        <td class="text-center">
                            <div class="btn-group btn-group-sm shadow-sm">
                                {{-- Tombol Detail --}}
                                <button type="button" class="btn btn-outline-info"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modalDetail{{ $alumni->id }}"
                                        title="Lihat Detail">
                                    <i class="bi bi-eye-fill"></i>
                                </button>

                                {{-- Tombol Reset Password (Memicu Modal) --}}
                                <button type="button" class="btn btn-outline-warning"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modalReset{{ $alumni->id }}"
                                        title="Reset Password">
                                    <i class="bi bi-key-fill"></i>
                                </button>

                                {{-- Tombol Hapus --}}
                                <button type="button" class="btn btn-outline-danger"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modalDelete{{ $alumni->id }}"
                                        title="Hapus Permanen">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Include Modal --}}
                    @include('admin.alumni.partials.modals', ['item' => $alumni])

                    @empty
                    <tr>
                        <td colspan="7" class="text-center py-5">
                            <p class="text-muted">Data alumni tidak ditemukan</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <small class="text-muted">Menampilkan {{ $alumnis->firstItem() ?? 0 }} sampai {{ $alumnis->lastItem() ?? 0 }} dari {{ $alumnis->total() }} alumni</small>
            {{ $alumnis->links() }}
        </div>
    </div>
</div>
@endsection
