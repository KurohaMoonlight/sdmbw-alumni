<div class="modal fade" id="modalDetail{{ $item->id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-light border-bottom-0 py-3">
                <h5 class="modal-title fw-bold"><i class="bi bi-person-badge me-2 text-primary"></i>Detail Profil Alumni</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row g-4">
                    <div class="col-md-6">
                        <small class="text-muted d-block mb-1 text-uppercase fw-bold">Nama Lengkap</small>
                        <p class="fw-bold h6 text-dark">{{ $item->nama_lengkap }}</p>
                    </div>
                    <div class="col-md-6">
                        <small class="text-muted d-block mb-1 text-uppercase fw-bold">NISN</small>
                        <p class="fw-bold h6 text-primary">{{ $item->nisn }}</p>
                    </div>
                    <div class="col-md-6">
                        <small class="text-muted d-block mb-1 text-uppercase fw-bold">Angkatan</small>
                        <p class="fw-bold h6">{{ $item->angkatan->nama_angkatan ?? '-' }}</p>
                    </div>
                    <div class="col-md-6">
                        <small class="text-muted d-block mb-1 text-uppercase fw-bold">Tahun Lulus</small>
                        <p class="fw-bold h6">{{ $item->tahun_lulus }}</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light border-top-0">
                <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Tutup</button>
                @if($item->status_verifikasi == 'pending')
                <form action="{{ route('admin.alumni.verify', $item->id) }}" method="POST">
                    @csrf @method('PATCH')
                    <button type="submit" class="btn btn-success px-4 fw-bold shadow-sm">Verifikasi Sekarang</button>
                </form>
                @endif
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalReset{{ $item->id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-body text-center p-4">
                <i class="bi bi-shield-lock text-warning display-4 mb-3"></i>
                <h5 class="fw-bold">Reset Password</h5>
                <p>Reset password <strong>{{ $item->nama_lengkap }}</strong>?</p>
                <div class="alert alert-light border shadow-sm small">Password akan menjadi: <strong>{{ $item->nisn }}</strong></div>
                <form action="{{ route('admin.alumni.reset-password', $item->id) }}" method="POST">
                    @csrf @method('PATCH')
                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-warning fw-bold text-white shadow-sm">Ya, Reset Password</button>
                        <button type="button" class="btn btn-link text-muted" data-bs-dismiss="modal">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalDelete{{ $item->id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-body text-center p-5">
                <i class="bi bi-exclamation-triangle text-danger display-1 mb-4"></i>
                <h4 class="fw-bold">Hapus Data?</h4>
                <p class="text-muted px-3">Data <strong>{{ $item->nama_lengkap }}</strong> akan dihapus permanen.</p>
                <form action="{{ route('admin.alumni.destroy', $item->id) }}" method="POST">
                    @csrf @method('DELETE')
                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-danger btn-lg shadow-sm fw-bold">Hapus Sekarang</button>
                        <button type="button" class="btn btn-link text-muted" data-bs-dismiss="modal">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
