@extends('layouts.admin')

@section('title', 'Laporan')
@section('page-title', 'Laporan & Statistik')

@section('content')
<!-- Statistik Umum -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="mb-1">{{ $stats['total_alumni'] }}</h3>
                <p class="text-muted mb-0 small">Total Alumni</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="mb-1 text-success">{{ $stats['alumni_verified'] }}</h3>
                <p class="text-muted mb-0 small">Alumni Verified</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="mb-1 text-warning">{{ $stats['alumni_pending'] }}</h3>
                <p class="text-muted mb-0 small">Menunggu Verifikasi</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="mb-1 text-primary">{{ $stats['profil_lengkap'] }}</h3>
                <p class="text-muted mb-0 small">Profil Lengkap</p>
            </div>
        </div>
    </div>
</div>

<!-- Statistik per Angkatan -->
<div class="card mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h6 class="mb-0">
            <i class="bi bi-calendar-event"></i> Statistik per Angkatan
        </h6>
        <button onclick="window.print()" class="btn btn-sm btn-outline-primary no-print">
            <i class="bi bi-printer"></i> <span class="d-none d-sm-inline">Print</span>
        </button>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-sm">
                <thead class="table-light">
                    <tr>
                        <th>Angkatan</th>
                        <th class="d-none d-md-table-cell">Tahun Ajaran</th>
                        <th class="d-none d-sm-table-cell">Status</th>
                        <th class="text-center">Alumni</th>
                        <th class="text-center d-none d-lg-table-cell">Verified</th>
                        <th class="text-center d-none d-lg-table-cell">Pending</th>
                        <th class="text-center d-none d-xl-table-cell">Lengkap</th>
                        <th class="no-print">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($angkatanStats as $angkatan)
                    <tr>
                        <td><strong>{{ $angkatan->nama_angkatan }}</strong></td>
                        <td class="d-none d-md-table-cell">{{ $angkatan->tahun_ajaran }}</td>
                        <td class="d-none d-sm-table-cell">
                            @if($angkatan->status == 'LULUS')
                                <span class="badge bg-success">LULUS</span>
                            @elseif($angkatan->status == 'AKTIF')
                                <span class="badge bg-warning">AKTIF</span>
                            @endif
                        </td>
                        <td class="text-center">
                            <strong>{{ $angkatan->alumni_count }}</strong>
                        </td>
                        <td class="text-center d-none d-lg-table-cell">
                            <span class="badge bg-success">{{ $angkatan->verified_count }}</span>
                        </td>
                        <td class="text-center d-none d-lg-table-cell">
                            <span class="badge bg-warning text-dark">{{ $angkatan->pending_count }}</span>
                        </td>
                        <td class="text-center d-none d-xl-table-cell">
                            <span class="badge bg-primary">{{ $angkatan->complete_count }}</span>
                        </td>
                        <td class="no-print">
                            <a href="{{ route('admin.laporan.angkatan', $angkatan->id) }}"
                                class="btn btn-sm btn-info">
                                <i class="bi bi-eye"></i><span class="d-none d-md-inline"> Detail</span>
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
                <tfoot class="table-light">
                    <tr>
                        <td colspan="3"><strong>TOTAL</strong></td>
                        <td class="text-center"><strong>{{ $stats['total_alumni'] }}</strong></td>
                        <td class="text-center d-none d-lg-table-cell"><strong>{{ $stats['alumni_verified'] }}</strong></td>
                        <td class="text-center d-none d-lg-table-cell"><strong>{{ $stats['alumni_pending'] }}</strong></td>
                        <td class="text-center d-none d-xl-table-cell"><strong>{{ $stats['profil_lengkap'] }}</strong></td>
                        <td class="no-print"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<div class="row g-3">
    <!-- Pendidikan Lanjutan -->
    <div class="col-12 col-lg-6">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h6 class="mb-0">
                    <i class="bi bi-book"></i> Top 10 Pendidikan Lanjutan
                </h6>
            </div>
            <div class="card-body">
                @if($pendidikanStats->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Sekolah/Universitas</th>
                                    <th class="text-center">Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($pendidikanStats as $item)
                                <tr>
                                    <td>{{ $item->pendidikan_lanjutan }}</td>
                                    <td class="text-center">
                                        <span class="badge bg-primary">{{ $item->total }}</span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <p class="text-muted text-center mb-0">Belum ada data</p>
                @endif
            </div>
        </div>
    </div>

    <!-- Pekerjaan -->
    <div class="col-12 col-lg-6">
        <div class="card h-100">
            <div class="card-header bg-white">
                <h6 class="mb-0">
                    <i class="bi bi-briefcase"></i> Top 10 Pekerjaan
                </h6>
            </div>
            <div class="card-body">
                @if($pekerjaanStats->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Pekerjaan</th>
                                    <th class="text-center">Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($pekerjaanStats as $item)
                                <tr>
                                    <td>{{ $item->pekerjaan }}</td>
                                    <td class="text-center">
                                        <span class="badge bg-primary">{{ $item->total }}</span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <p class="text-muted text-center mb-0">Belum ada data</p>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
