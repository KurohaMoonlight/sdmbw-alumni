@extends('layouts.admin')

@section('title', 'Laporan Angkatan')
@section('page-title', 'Laporan ' . $angkatan->nama_angkatan)

@section('content')
<div class="card mb-3">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <div>
            <h5 class="mb-1">{{ $angkatan->nama_angkatan }}</h5>
            <small class="text-muted">Tahun Ajaran: {{ $angkatan->tahun_ajaran }}</small>
        </div>
        <div>
            <a href="{{ route('admin.laporan.index') }}" class="btn btn-sm btn-secondary">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
            <button onclick="window.print()" class="btn btn-sm btn-primary">
                <i class="bi bi-printer"></i> Print
            </button>
        </div>
    </div>
    <div class="card-body">
        <!-- Statistik -->
        <div class="row g-3 mb-4">
            <div class="col-md-2">
                <div class="text-center">
                    <h4 class="mb-0">{{ $stats['total'] }}</h4>
                    <small class="text-muted">Total</small>
                </div>
            </div>
            <div class="col-md-2">
                <div class="text-center">
                    <h4 class="mb-0 text-success">{{ $stats['verified'] }}</h4>
                    <small class="text-muted">Verified</small>
                </div>
            </div>
            <div class="col-md-2">
                <div class="text-center">
                    <h4 class="mb-0 text-warning">{{ $stats['pending'] }}</h4>
                    <small class="text-muted">Pending</small>
                </div>
            </div>
            <div class="col-md-2">
                <div class="text-center">
                    <h4 class="mb-0 text-danger">{{ $stats['rejected'] }}</h4>
                    <small class="text-muted">Rejected</small>
                </div>
            </div>
            <div class="col-md-2">
                <div class="text-center">
                    <h4 class="mb-0 text-primary">{{ $stats['lengkap'] }}</h4>
                    <small class="text-muted">Profil Lengkap</small>
                </div>
            </div>
            <div class="col-md-2">
                <div class="text-center">
                    <h4 class="mb-0 text-secondary">{{ $stats['total'] - $stats['lengkap'] }}</h4>
                    <small class="text-muted">Belum Lengkap</small>
                </div>
            </div>
        </div>

        <hr>

        <!-- Daftar Alumni -->
        <h6 class="mb-3">Daftar Alumni</h6>
        <div class="table-responsive">
            <table class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NISN</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>No. HP</th>
                        <th>Pendidikan Lanjutan</th>
                        <th>Pekerjaan</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($alumni as $index => $alum)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $alum->nisn }}</td>
                        <td>{{ $alum->nama_lengkap }}</td>
                        <td>{{ $alum->user->username ?? '-' }}</td>
                        <td>{{ $alum->no_hp ?? '-' }}</td>
                        <td>{{ $alum->pendidikan_lanjutan ?? '-' }}</td>
                        <td>{{ $alum->pekerjaan ?? '-' }}</td>
                        <td>
                            @if($alum->status_verifikasi == 'verified')
                                <span class="badge bg-success">Verified</span>
                            @elseif($alum->status_verifikasi == 'pending')
                                <span class="badge bg-warning">Pending</span>
                            @else
                                <span class="badge bg-danger">Rejected</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="text-center text-muted">Belum ada alumni di angkatan ini</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@push('styles')
<style>
    @media print {
        .sidebar,
        .topbar,
        .btn,
        .no-print {
            display: none !important;
        }
        .main-content {
            margin-left: 0 !important;
        }
    }
</style>
@endpush
@endsection
