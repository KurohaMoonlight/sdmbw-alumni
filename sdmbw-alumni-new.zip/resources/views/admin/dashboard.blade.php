@extends('layouts.admin')

@section('title', 'Dashboard Admin')
@section('page-title', 'Ringkasan Sistem')

@section('content')
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <a href="{{ route('admin.alumni.index') }}" class="text-decoration-none">
            <div class="stats-card primary shadow-sm">
                <div class="icon">
                    <i class="bi bi-people-fill"></i>
                </div>
                <h3>{{ $stats['total_alumni'] }}</h3>
                <p>Total Alumni</p>
            </div>
        </a>
    </div>

    <div class="col-md-3">
        <div class="stats-card success shadow-sm">
            <div class="icon">
                <i class="bi bi-check-circle-fill"></i>
            </div>
            <h3>{{ $stats['alumni_verified'] }}</h3>
            <p>Terverifikasi</p>
        </div>
    </div>

    <div class="col-md-3">
        <a href="{{ route('admin.alumni.index') }}?status=pending" class="text-decoration-none">
            <div class="stats-card warning shadow-sm position-relative">
                @if($stats['alumni_pending'] > 0)
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $stats['alumni_pending'] }}
                        <span class="visually-hidden">unread messages</span>
                    </span>
                @endif
                <div class="icon">
                    <i class="bi bi-clock-fill"></i>
                </div>
                <h3>{{ $stats['alumni_pending'] }}</h3>
                <p>Butuh Verifikasi</p>
            </div>
        </a>
    </div>

    <div class="col-md-3">
        <div class="stats-card danger shadow-sm">
            <div class="icon">
                <i class="bi bi-person-check-fill"></i>
            </div>
            <h3>{{ $stats['profil_lengkap'] }}</h3>
            <p>Profil Lengkap</p>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-7">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white py-3">
                <h6 class="mb-0 fw-bold">
                    <i class="bi bi-bar-chart-fill text-primary me-2"></i>Statistik Per Angkatan
                </h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Angkatan</th>
                                <th>Tahun Ajaran</th>
                                <th>Status</th>
                                <th class="text-center">Jumlah Alumni</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($angkatanStats as $angkatan)
                            <tr>
                                <td class="fw-bold">{{ $angkatan->nama_angkatan }}</td>
                                <td>{{ $angkatan->tahun_ajaran }}</td>
                                <td>
                                    @if($angkatan->status == 'LULUS')
                                        <span class="badge rounded-pill bg-light-success text-success border border-success px-3">LULUS</span>
                                    @elseif($angkatan->status == 'AKTIF')
                                        <span class="badge rounded-pill bg-light-warning text-warning border border-warning px-3">AKTIF</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    <span class="fw-bold">{{ $angkatan->alumni_count }}</span> Orang
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted">Belum ada data angkatan</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-5">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold">
                    <i class="bi bi-person-plus-fill text-primary me-2"></i>Pendaftar Terbaru
                </h6>
                <a href="{{ route('admin.alumni.index') }}" class="btn btn-sm btn-outline-primary px-3">Lihat Semua</a>
            </div>
            <div class="card-body">
                @forelse($recentAlumni as $alumni)
                <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                    <div class="d-flex align-items-center">
                        <div class="avatar-sm me-3 bg-light rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                            <i class="bi bi-person text-secondary"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 small fw-bold">{{ $alumni->nama_lengkap }}</h6>
                            <small class="text-muted" style="font-size: 11px;">
                                {{ $alumni->angkatan->nama_angkatan ?? 'Tanpa Angkatan' }}
                            </small>
                        </div>
                    </div>
                    <div>
                        @if($alumni->status_verifikasi == 'verified')
                            <span class="badge bg-success small">Verified</span>
                        @elseif($alumni->status_verifikasi == 'pending')
                            <span class="badge bg-warning text-dark small pulse">Pending</span>
                        @else
                            <span class="badge bg-danger small">Rejected</span>
                        @endif
                    </div>
                </div>
                @empty
                <div class="text-center py-5">
                    <i class="bi bi-inbox text-muted" style="font-size: 2rem;"></i>
                    <p class="text-muted mt-2">Belum ada pendaftar baru</p>
                </div>
                @endforelse
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="alert alert-light border-start border-info border-4 shadow-sm py-3">
            <div class="d-flex align-items-center">
                <i class="bi bi-info-circle-fill text-info fs-4 me-3"></i>
                <div>
                    <h6 class="mb-0 fw-bold">Ringkasan Kelulusan</h6>
                    <p class="mb-0 small text-muted">Sistem mencatat <strong>{{ $stats['angkatan_aktif'] }}</strong> angkatan dalam status aktif, <strong>{{ $stats['angkatan_lulus'] }}</strong> angkatan telah lulus.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Tambahkan sedikit sentuhan animasi untuk badge pending */
    .pulse {
        animation: pulse-animation 2s infinite;
    }

    @keyframes pulse-animation {
        0% { box-shadow: 0 0 0 0px rgba(255, 193, 7, 0.4); }
        100% { box-shadow: 0 0 0 10px rgba(255, 193, 7, 0); }
    }

    .bg-light-success { background-color: rgba(25, 135, 84, 0.1); }
    .bg-light-warning { background-color: rgba(255, 193, 7, 0.1); }
</style>
@endsection
