<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin') - SDMBW Alumni</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">

    <style>
        :root {
            --color-primary: #213448;
            --color-primary-light: #2d4a63;
            --color-primary-dark: #1a2937;
            --color-bg: #f8f9fa;
            --color-secondary: #6c757d;
            --color-accent: #0d6efd;
            --sidebar-width: 260px;
            --topbar-height: 70px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background: var(--color-bg);
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
            color: white;
            padding: 20px 0;
            z-index: 1050;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,0.2) transparent;
        }

        .sidebar::-webkit-scrollbar { width: 6px; }
        .sidebar::-webkit-scrollbar-track { background: transparent; }
        .sidebar::-webkit-scrollbar-thumb {
            background-color: rgba(255,255,255,0.2);
            border-radius: 20px;
        }

        .sidebar-brand {
            padding: 0 25px 25px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
            margin-bottom: 20px;
        }

        .sidebar-brand h4 {
            font-family: 'Poppins', sans-serif;
            font-size: 20px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
            color: #ffffff;
        }

        .sidebar-brand small {
            font-size: 12px;
            opacity: 0.8;
            color: #e0e0e0;
        }

        .sidebar-menu { list-style: none; padding: 0; }

        .sidebar-menu li a {
            display: flex;
            align-items: center;
            padding: 14px 25px;
            color: rgba(255,255,255,0.9);
            text-decoration: none;
            transition: all 0.2s ease-in-out;
            border-left: 4px solid transparent;
            font-weight: 500;
        }

        .sidebar-menu li a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border-left-color: #0d6efd;
            padding-left: 30px;
        }

        .sidebar-menu li a.active {
            background: rgba(13, 110, 253, 0.2);
            color: white;
            border-left-color: #0d6efd;
            font-weight: 600;
        }

        .sidebar-menu li a i {
            margin-right: 12px;
            font-size: 1.15rem;
            width: 25px;
            text-align: center;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 25px;
            min-height: 100vh;
            transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* ===== TOPBAR ===== */
        .topbar {
            background: white;
            padding: 18px 25px;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(33, 52, 72, 0.08);
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            min-height: var(--topbar-height);
            border-left: 4px solid var(--color-primary);
        }

        .topbar h5 {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            color: var(--color-primary);
            font-size: 1.25rem;
            font-weight: 700;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--color-primary);
            font-size: 0.95rem;
            font-weight: 500;
        }

        .btn-logout {
            background: var(--color-primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 2px 8px rgba(33, 52, 72, 0.2);
        }

        .btn-logout:hover {
            background: var(--color-primary-light);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(33, 52, 72, 0.3);
        }

        /* ===== MOBILE ELEMENTS ===== */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 18px;
            left: 18px;
            z-index: 1100;
            background: var(--color-primary);
            color: white;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(33, 52, 72, 0.3);
            cursor: pointer;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .sidebar-toggle:hover {
            background: var(--color-primary-light);
            transform: scale(1.05);
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(33, 52, 72, 0.7);
            z-index: 1040;
            backdrop-filter: blur(4px);
            opacity: 0;
            transition: opacity 0.3s;
        }

        /* ===== ALERTS ===== */
        .alert {
            border-radius: 10px;
            border: none;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }

        .alert-danger {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
        }

        /* ===== STATS CARD ===== */
        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 12px rgba(33, 52, 72, 0.08);
            height: 100%;
            transition: all 0.3s;
            border-top: 3px solid transparent;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(33, 52, 72, 0.15);
        }

        .stats-card .icon {
            width: 55px;
            height: 55px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            margin-bottom: 15px;
        }

        .stats-card h3 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--color-primary);
            margin-bottom: 5px;
            font-family: 'Poppins', sans-serif;
        }

        .stats-card p {
            color: var(--color-secondary);
            margin: 0;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .stats-card.primary { border-top-color: #0d6efd; }
        .stats-card.primary .icon { background: rgba(13, 110, 253, 0.1); color: #0d6efd; }

        .stats-card.success { border-top-color: #28a745; }
        .stats-card.success .icon { background: rgba(40, 167, 69, 0.1); color: #28a745; }

        .stats-card.warning { border-top-color: #ffc107; }
        .stats-card.warning .icon { background: rgba(255, 193, 7, 0.1); color: #ffc107; }

        .stats-card.danger { border-top-color: #dc3545; }
        .stats-card.danger .icon { background: rgba(220, 53, 69, 0.1); color: #dc3545; }

        /* ===== RESPONSIVE ===== */

        /* Tablet & Mobile (Max 991px) */
        @media (max-width: 991.98px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.show {
                transform: translateX(0);
                box-shadow: 5px 0 25px rgba(33, 52, 72, 0.3);
            }

            .main-content {
                margin-left: 0;
                padding: 20px;
                padding-top: 80px;
            }

            .sidebar-toggle { display: flex; }
            .sidebar-overlay.show { display: block; opacity: 1; }

            .topbar {
                padding: 15px 20px;
                flex-wrap: wrap;
            }
        }

        /* Mobile Phone (Max 576px) */
        @media (max-width: 575.98px) {
            .sidebar { width: 280px; }

            .main-content {
                padding: 15px;
                padding-top: 75px;
            }

            .topbar {
                flex-direction: column;
                align-items: stretch;
                gap: 15px;
                padding: 15px;
                padding-left: 65px;
            }

            .topbar h5 {
                font-size: 1.1rem;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }

            .user-menu {
                justify-content: space-between;
                width: 100%;
                border-top: 1px solid #e9ecef;
                padding-top: 12px;
            }

            .user-info {
                font-size: 0.9rem;
            }

            .user-info span {
                max-width: 120px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }

            .btn-logout {
                padding: 8px 14px;
                font-size: 0.85rem;
            }

            .stats-card {
                padding: 20px;
            }

            .stats-card h3 {
                font-size: 1.6rem;
            }
        }

        /* Extra Small (Max 375px) */
        @media (max-width: 375px) {
            .sidebar { width: 260px; }

            .sidebar-toggle {
                width: 40px;
                height: 40px;
                top: 15px;
                left: 15px;
            }

            .topbar h5 {
                font-size: 1rem;
            }

            .btn-logout {
                padding: 6px 12px;
                font-size: 0.8rem;
            }
        }
    </style>

    @stack('styles')
</head>
<body id="body-pd">

    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Menu">
        <i class="bi bi-list fs-4"></i>
    </button>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <h4>ADMIN PANEL</h4>
            <small>SD Muhammadiyah BW</small>
        </div>

        <ul class="sidebar-menu">
            <li>
                <a href="{{ route('admin.dashboard') }}" class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                    <i class="bi bi-speedometer2"></i> <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.angkatan.index') }}" class="{{ request()->routeIs('admin.angkatan.*') ? 'active' : '' }}">
                    <i class="bi bi-calendar-event"></i> <span>Kelola Angkatan</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.alumni.index') }}" class="{{ request()->routeIs('admin.alumni.*') ? 'active' : '' }}">
                    <i class="bi bi-people"></i> <span>Kelola Alumni</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.laporan.index') }}" class="{{ request()->routeIs('admin.laporan.*') ? 'active' : '' }}">
                    <i class="bi bi-file-earmark-text"></i> <span>Laporan</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.logs.index') }}" class="{{ request()->routeIs('admin.logs.*') ? 'active' : '' }}">
                    <i class="bi bi-clock-history"></i> <span>Activity Logs</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <div class="topbar">
            <h5>@yield('page-title', 'Dashboard')</h5>

            <div class="user-menu">
                <div class="user-info">
                    <i class="bi bi-person-circle fs-5"></i>
                    <span>{{ Auth::user()->username }}</span>
                </div>

                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button type="submit" class="btn btn-logout">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </button>
                </form>
            </div>
        </div>

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i> {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @yield('content')
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('sidebarToggle');
            const overlay = document.getElementById('sidebarOverlay');
            const body = document.body;

            function toggleMenu(show) {
                if (show) {
                    sidebar.classList.add('show');
                    overlay.classList.add('show');
                    if(window.innerWidth < 992) {
                        body.style.overflow = 'hidden';
                    }
                } else {
                    sidebar.classList.remove('show');
                    overlay.classList.remove('show');
                    body.style.overflow = '';
                }
            }

            if(toggle) {
                toggle.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const isOpen = sidebar.classList.contains('show');
                    toggleMenu(!isOpen);
                });
            }

            if(overlay) {
                overlay.addEventListener('click', () => toggleMenu(false));
            }

            const menuLinks = document.querySelectorAll('.sidebar-menu a');
            menuLinks.forEach(link => {
                link.addEventListener('click', () => {
                    if (window.innerWidth < 992) {
                        toggleMenu(false);
                    }
                });
            });

            window.addEventListener('resize', () => {
                if (window.innerWidth >= 992) {
                    sidebar.classList.remove('show');
                    overlay.classList.remove('show');
                    body.style.overflow = '';
                }
            });
        });
    </script>

    @stack('scripts')
</body>
</html>
