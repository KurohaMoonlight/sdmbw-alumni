@extends('layouts.alumni')

@section('title', 'Dashboard Alumni')

@section('content')
<div class="row">
    <div class="col-md-8">

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Status Akun</h5>

                <div class="row g-3">
                    <div class="col-md-6">
                        <small class="text-muted d-block mb-1">Status Verifikasi</small>
                        @if($alumni->status_verifikasi == 'verified')
                            <span class="badge bg-success py-2 px-3 rounded-pill">
                                <i class="bi bi-check-circle-fill me-1"></i> Terverifikasi
                            </span>
                        @elseif($alumni->status_verifikasi == 'pending')
                            <span class="badge bg-secondary py-2 px-3 rounded-pill">
                                <i class="bi bi-clock-fill me-1"></i> Menunggu Verifikasi
                            </span>
                        @else
                            <span class="badge bg-danger py-2 px-3 rounded-pill">
                                <i class="bi bi-x-circle-fill me-1"></i> Ditolak
                            </span>
                        @endif
                    </div>

                    <div class="col-md-6">
                        <small class="text-muted d-block mb-1">Kelengkapan Profil</small>
                        @if($alumni->is_profile_complete)
                            <span class="badge bg-primary py-2 px-3 rounded-pill">
                                <i class="bi bi-check-all me-1"></i> Data Lengkap
                            </span>
                        @else
                            <span class="badge bg-warning text-dark py-2 px-3 rounded-pill">
                                <i class="bi bi-exclamation-triangle-fill me-1"></i> Belum Lengkap
                            </span>
                        @endif
                    </div>
                </div>

                @if($alumni->status_verifikasi == 'pending')
                    <div class="alert alert-info border-0 shadow-sm mt-3 mb-0 d-flex align-items-center">
                        <i class="bi bi-info-circle-fill fs-4 me-3"></i>
                        <div>
                            <strong>Info:</strong> Akun Anda sedang ditinjau oleh Admin.
                            Silakan lengkapi biodata sambil menunggu.
                        </div>
                    </div>
                @endif

                @if(!$alumni->is_profile_complete)
                    <div class="alert alert-warning border-0 shadow-sm mt-3 mb-0 d-flex align-items-center">
                        <i class="bi bi-exclamation-triangle-fill fs-4 me-3"></i>
                        <div>
                            <strong>Perhatian:</strong> Profil Anda belum lengkap.
                            <a href="{{ route('alumni.profile.edit') }}" class="fw-bold text-decoration-none text-dark stretched-link">
                                Lengkapi Sekarang <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                @endif
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h6 class="mb-0 fw-bold text-primary">
                    <i class="bi bi-person-lines-fill me-2"></i> Biodata Diri
                </h6>
            </div>
            <div class="card-body">
                <div class="row mb-3 border-bottom pb-2">
                    <div class="col-md-4 text-secondary">NISN</div>
                    <div class="col-md-8 fw-bold">{{ $alumni->nisn }}</div>
                </div>

                <div class="row mb-3 border-bottom pb-2">
                    <div class="col-md-4 text-secondary">Nama Lengkap</div>
                    <div class="col-md-8 fw-bold">{{ $alumni->nama_lengkap }}</div>
                </div>

                <div class="row mb-3 border-bottom pb-2">
                    <div class="col-md-4 text-secondary">Angkatan</div>
                    <div class="col-md-8">
                        <span class="badge bg-light text-dark border">
                            {{ $alumni->angkatan->nama_angkatan ?? '-' }}
                        </span>
                        <small class="text-muted ms-1">({{ $alumni->angkatan->tahun_ajaran ?? '-' }})</small>
                    </div>
                </div>

                <div class="row mb-3 border-bottom pb-2">
                    <div class="col-md-4 text-secondary">Tahun Lulus</div>
                    <div class="col-md-8 fw-bold">{{ $alumni->tahun_lulus }}</div>
                </div>

                <div class="row mb-3 border-bottom pb-2">
                    <div class="col-md-4 text-secondary">Alamat Domisili</div>
                    <div class="col-md-8">
                        @if($alumni->alamat)
                            {{ $alumni->alamat }}
                        @else
                            <span class="badge bg-warning text-dark"><i class="bi bi-pencil me-1"></i> Belum diisi</span>
                        @endif
                    </div>
                </div>

                <div class="row mb-3 border-bottom pb-2">
                    <div class="col-md-4 text-secondary">No. Handphone</div>
                    <div class="col-md-8">
                        @if($alumni->no_hp)
                            {{ $alumni->no_hp }}
                        @else
                            <span class="badge bg-warning text-dark"><i class="bi bi-pencil me-1"></i> Belum diisi</span>
                        @endif
                    </div>
                </div>

                <div class="row mb-3 border-bottom pb-2">
                    <div class="col-md-4 text-secondary">Email</div>
                    <div class="col-md-8 text-break">{{ $alumni->email ?? '-' }}</div>
                </div>

                <div class="row mb-3 border-bottom pb-2">
                    <div class="col-md-4 text-secondary">Pendidikan Lanjutan</div>
                    <div class="col-md-8">
                        @if($alumni->pendidikan_lanjutan)
                            {{ $alumni->pendidikan_lanjutan }}
                        @else
                            <span class="text-muted fst-italic">- Tidak diisi -</span>
                        @endif
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4 text-secondary">Pekerjaan</div>
                    <div class="col-md-8">
                        {{ $alumni->pekerjaan ?? '-' }}
                    </div>
                </div>

                <div class="text-end mt-4">
                    <a href="{{ route('alumni.profile.edit') }}" class="btn btn-primary px-4">
                        <i class="bi bi-pencil-square me-2"></i> Edit Profil
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">

        <div class="card border-0 shadow-sm mb-4 text-center">
            <div class="card-body py-5">
                <div class="mb-3">
                    @if($alumni->user && $alumni->user->foto_profil)
                        <img src="{{ asset('storage/' . $alumni->user->foto_profil) }}" class="rounded-circle shadow-sm" style="width: 100px; height: 100px; object-fit: cover;">
                    @else
                        <i class="bi bi-person-circle text-secondary" style="font-size: 80px;"></i>
                    @endif
                </div>
                <h5 class="fw-bold mb-1">{{ $alumni->nama_lengkap }}</h5>
                <p class="text-muted mb-2">{{ $alumni->angkatan->nama_angkatan ?? 'Alumni' }}</p>
                <span class="badge bg-light text-secondary border">
                    {{ Auth::user()->username ?? 'User' }}
                </span>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h6 class="mb-0 fw-bold">
                    <i class="bi bi-shield-lock me-2"></i> Informasi Akun
                </h6>
            </div>
            <div class="card-body small">
                <ul class="list-unstyled mb-0">
                    <li class="mb-3 d-flex align-items-center">
                        <i class="bi bi-calendar-check text-success fs-5 me-3"></i>
                        <div>
                            <span class="d-block text-muted">Tanggal Registrasi</span>
                            <strong>{{ optional($alumni->created_at)->format('d M Y') ?? '-' }}</strong>
                        </div>
                    </li>
                    <li class="mb-3 d-flex align-items-center">
                        <i class="bi bi-arrow-repeat text-primary fs-5 me-3"></i>
                        <div>
                            <span class="d-block text-muted">Update Terakhir</span>
                            <strong>{{ optional($alumni->updated_at)->format('d M Y H:i') ?? '-' }}</strong>
                        </div>
                    </li>
                    @if(Auth::user()->last_login_at)
                    <li class="d-flex align-items-center">
                        <i class="bi bi-box-arrow-in-right text-warning fs-5 me-3"></i>
                        <div>
                            <span class="d-block text-muted">Login Terakhir</span>
                            <strong>{{ optional(Auth::user()->last_login_at)->format('d M Y H:i') }}</strong>
                        </div>
                    </li>
                    @endif
                </ul>
            </div>
        </div>

    </div>
</div>
@endsection
