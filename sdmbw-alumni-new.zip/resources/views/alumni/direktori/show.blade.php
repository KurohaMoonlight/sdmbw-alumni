@extends('layouts.alumni')

@section('title', 'Profil ' . $alumni->nama_lengkap)

@section('content')
<div class="container-fluid">
    <div class="mb-4">
        <a href="{{ route('alumni.direktori') }}" class="text-decoration-none fw-bold" style="color: #213448;">
            <i class="bi bi-arrow-left"></i> Kembali ke Direktori
        </a>
    </div>

    <div class="row">
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm text-center p-4 mb-4" style="border-radius: 15px;">
                <div class="card-body">
                    <div class="mb-3">
                        @if($alumni->foto)
                            <img src="{{ asset('storage/'.$alumni->foto) }}" class="rounded-circle border" style="width: 150px; height: 150px; object-fit: cover;">
                        @else
                            <div class="rounded-circle d-inline-flex align-items-center justify-content-center border mx-auto"
                                 style="width: 150px; height: 150px; background-color: #f8f9fa;">
                                <span class="display-3 fw-bold" style="color: #213448;">{{ strtoupper(substr($alumni->nama_lengkap, 0, 1)) }}</span>
                            </div>
                        @endif
                    </div>
                    <h4 class="fw-bold mb-1" style="color: #213448;">{{ $alumni->nama_lengkap }}</h4>
                    <p class="badge px-3 py-2 mb-0" style="background-color: #213448;">
                        {{ $alumni->angkatan->nama_angkatan }}
                    </p>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                <div class="card-header bg-white py-3" style="border-bottom: 1px solid #eee;">
                    <h5 class="fw-bold mb-0" style="color: #213448;">Informasi Lengkap</h5>
                </div>
                <div class="card-body p-4">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <label class="small text-muted d-block">Nama Lengkap</label>
                            <span class="fw-bold text-dark">{{ $alumni->nama_lengkap }}</span>
                        </div>
                        <div class="col-md-6">
                            <label class="small text-muted d-block">Angkatan</label>
                            <span class="fw-bold text-dark">{{ $alumni->angkatan->nama_angkatan }}</span>
                        </div>
                        <div class="col-md-6">
                            <label class="small text-muted d-block">Tahun Ajaran</label>
                            <span class="fw-bold text-dark">{{ $alumni->angkatan->tahun_ajaran }}</span>
                        </div>
                        <div class="col-md-6">
                            <label class="small text-muted d-block">Status Kelulusan</label>
                            <span class="badge {{ $alumni->angkatan->status == 'LULUS' ? 'bg-success' : 'bg-warning' }}">
                                {{ $alumni->angkatan->status }}
                            </span>
                        </div>

                        <div class="col-12">
                            <hr class="text-muted opacity-25">
                            <label class="small text-muted d-block mb-2">Kontak / Media Sosial</label>
                            <div class="d-flex gap-2 flex-wrap">
                                @if($alumni->email)
                                    <span class="badge bg-light text-dark border p-2"><i class="bi bi-envelope me-1"></i> {{ $alumni->email }}</span>
                                @else
                                    <span class="text-muted small italic">Informasi kontak tidak tersedia.</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Pendidikan Lanjutan --}}
    @if($alumni->pendidikan_lanjutan)
    <div class="row mt-4">
        <div class="col-lg-12">
            <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                <div class="card-header bg-white py-3" style="border-bottom: 1px solid #eee;">
                    <h5 class="fw-bold mb-0" style="color: #213448;">Pendidikan Lanjutan</h5>
                </div>
                <div class="card-body p-4">
                    <span class="text-dark">{{ $alumni->pendidikan_lanjutan }}</span>
                </div>
            </div>
        </div>
    </div>
    @endif

    {{-- Pekerjaan --}}
    @if($alumni->pekerjaan)
    <div class="row mt-4">
        <div class="col-lg-12">
            <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                <div class="card-header bg-white py-3" style="border-bottom: 1px solid #eee;">
                    <h5 class="fw-bold mb-0" style="color: #213448;">Pekerjaan</h5>
                </div>
                <div class="card-body p-4">
                    <span class="text-dark">{{ $alumni->pekerjaan }}</span>
                </div>
            </div>
        </div>
    </div>
    @endif

    {{-- Harapan --}}
    @if($alumni->harapan)
    <div class="row mt-4">
        <div class="col-lg-12">
            <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                <div class="card-header bg-white py-3" style="border-bottom: 1px solid #eee;">
                    <h5 class="fw-bold mb-0" style="color: #213448;">Harapan</h5>
                </div>
                <div class="card-body p-4">
                    <span class="text-dark" style="line-height: 1.6;">{{ $alumni->harapan }}</span>
                </div>
            </div>
        </div>
    </div>
    @endif

    {{-- Pesan --}}
    @if($alumni->pesan)
    <div class="row mt-4">
        <div class="col-lg-12">
            <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                <div class="card-header bg-white py-3" style="border-bottom: 1px solid #eee;">
                    <h5 class="fw-bold mb-0" style="color: #213448;">Pesan</h5>
                </div>
                <div class="card-body p-4">
                    <span class="text-dark" style="line-height: 1.6;">{{ $alumni->pesan }}</span>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>

<style>
    .card {
        transition: none;
    }
    label {
        letter-spacing: 0.5px;
        text-transform: uppercase;
        margin-bottom: 2px;
    }
</style>
@endsection
