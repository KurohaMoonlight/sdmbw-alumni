@extends('layouts.alumni')

@section('title', 'Edit Profil')

@section('content')
<div class="row">
    <div class="col-md-8">
        <!-- Form Edit Profil -->
        <div class="card card-custom">
            <div class="card-header card-header-custom">
                <h6 class="mb-0">
                    <i class="bi bi-pencil"></i> Edit Profil Alumni
                </h6>
            </div>
            <div class="card-body">
                @if($errors->any())
                    <div class="alert alert-danger">
                        <strong>Terjadi kesalahan:</strong>
                        <ul class="mb-0 mt-2">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('alumni.profile.update') }}" method="POST">
                    @csrf
                    @method('PUT')

                    <h6 class="text-muted mb-3">Data yang Tidak Bisa Diubah</h6>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">NISN</label>
                            <input type="text" class="form-control" value="{{ $alumni->nisn }}" disabled>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" value="{{ $alumni->nama_lengkap }}" disabled>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Angkatan</label>
                            <input type="text" class="form-control" value="{{ $alumni->angkatan->nama_angkatan ?? '-' }}" disabled>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Tahun Lulus</label>
                            <input type="text" class="form-control" value="{{ $alumni->tahun_lulus }}" disabled>
                        </div>
                    </div>

                    <hr class="my-4">

                    <h6 class="text-muted mb-3">Data yang Bisa Diubah</h6>

                    <div class="mb-3">
                        <label for="alamat" class="form-label">
                            Alamat <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control @error('alamat') is-invalid @enderror"
                                  id="alamat"
                                  name="alamat"
                                  rows="3"
                                  placeholder="Alamat lengkap sesuai KTP"
                                  required>{{ old('alamat', $alumni->alamat) }}</textarea>
                        @error('alamat')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="no_hp" class="form-label">
                                Nomor HP <span class="text-danger">*</span>
                            </label>
                            <input type="tel"
                                class="form-control @error('no_hp') is-invalid @enderror"
                                id="no_hp"
                                name="no_hp"
                                value="{{ old('no_hp', $alumni->no_hp) }}"
                                placeholder="08xxxxxxxxxx"
                                required
                                oninput="this.value = this.value.replace(/[^0-9]/g, '')"
                                inputmode="numeric"
                                minlength="10"
                                maxlength="14"
                                pattern="[0-9]+">
                            @error('no_hp')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="text-muted" style="font-size: 0.8em;">Hanya angka (10-14 digit)</small>
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email"
                                   class="form-control @error('email') is-invalid @enderror"
                                   id="email"
                                   name="email"
                                   value="{{ old('email', $alumni->email) }}"
                                   placeholder="email@example.com">
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="pendidikan_lanjutan" class="form-label">
                            Pendidikan Lanjutan <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               class="form-control @error('pendidikan_lanjutan') is-invalid @enderror"
                               id="pendidikan_lanjutan"
                               name="pendidikan_lanjutan"
                               value="{{ old('pendidikan_lanjutan', $alumni->pendidikan_lanjutan) }}"
                               placeholder="Contoh: SMP Negeri 1 Kudus"
                               required>
                        @error('pendidikan_lanjutan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <small class="form-text text-muted">
                            Isi dengan nama sekolah/universitas lanjutan
                        </small>
                    </div>

                    <div class="mb-3">
                        <label for="pekerjaan" class="form-label">Pekerjaan</label>
                        <input type="text"
                               class="form-control @error('pekerjaan') is-invalid @enderror"
                               id="pekerjaan"
                               name="pekerjaan"
                               value="{{ old('pekerjaan', $alumni->pekerjaan) }}"
                               placeholder="Kosongkan jika belum bekerja">
                        @error('pekerjaan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="harapan" class="form-label">Harapan & Pesan</label>
                        <textarea class="form-control @error('harapan') is-invalid @enderror"
                                  id="harapan"
                                  name="harapan"
                                  rows="4"
                                  placeholder="Harapan atau pesan untuk sekolah">{{ old('harapan', $alumni->harapan) }}</textarea>
                        @error('harapan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between">
                        <a href="{{ route('alumni.dashboard') }}" class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary-custom">
                            <i class="bi bi-save"></i> Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <!-- Info -->
        <div class="alert alert-info">
            <h6><i class="bi bi-info-circle"></i> Panduan</h6>
            <hr>
            <ul class="mb-0">
                <li>Field bertanda <span class="text-danger">*</span> wajib diisi</li>
                <li>Data NISN, Nama, Angkatan, dan Tahun Lulus tidak bisa diubah</li>
                <li>Pastikan data yang diisi benar dan sesuai</li>
                <li>Profil akan diverifikasi oleh admin</li>
            </ul>
        </div>

        <!-- Ganti Password -->
        <div class="card card-custom">
            <div class="card-header card-header-custom">
                <h6 class="mb-0">
                    <i class="bi bi-key"></i> Ganti Password
                </h6>
            </div>
            <div class="card-body">
                <form action="{{ route('alumni.profile.updatePassword') }}" method="POST">
                    @csrf
                    @method('PUT')

                    <div class="mb-3">
                        <label for="current_password" class="form-label">Password Lama</label>
                        <input type="password"
                               class="form-control @error('current_password') is-invalid @enderror"
                               id="current_password"
                               name="current_password"
                               required>
                        @error('current_password')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password Baru</label>
                        <input type="password"
                               class="form-control @error('password') is-invalid @enderror"
                               id="password"
                               name="password"
                               required>
                        @error('password')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="password_confirmation" class="form-label">Konfirmasi Password</label>
                        <input type="password"
                               class="form-control"
                               id="password_confirmation"
                               name="password_confirmation"
                               required>
                    </div>

                    <button type="submit" class="btn btn-warning w-100">
                        <i class="bi bi-shield-lock"></i> Ubah Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    /* Enhanced Form Labels */
    .form-label {
        font-weight: 600;
        color: var(--color-primary);
        margin-bottom: 0.5rem;
    }

    /* Enhanced Form Controls */
    .form-control {
        border: 2px solid #e9ecef;
        border-radius: 8px;
        padding: 0.65rem 0.85rem;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        border-color: var(--color-primary);
        box-shadow: 0 0 0 0.2rem rgba(33, 52, 72, 0.1);
    }

    .form-control:disabled {
        background: rgba(33, 52, 72, 0.05);
        color: #6c757d;
        font-weight: 500;
    }

    /* Section Titles */
    h6.text-muted {
        color: var(--color-primary) !important;
        font-weight: 700;
        font-size: 1.05rem;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid rgba(33, 52, 72, 0.1);
    }

    /* Divider */
    hr {
        border-top: 1px solid rgba(33, 52, 72, 0.1);
    }

    /* Alert Info */
    .alert-info {
        background: linear-gradient(135deg, #d1ecf1 0%, #bee5eb 100%);
        border: none;
        border-left: 4px solid #0dcaf0;
        border-radius: 10px;
    }

    .alert-info h6 {
        color: #055160;
        font-weight: 700;
        margin-bottom: 0.75rem;
    }

    .alert-info ul li {
        color: #055160;
        margin-bottom: 0.5rem;
    }

    /* Alert Danger */
    .alert-danger {
        background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
        border: none;
        border-left: 4px solid #dc3545;
        border-radius: 10px;
    }

    .alert-danger strong {
        color: #721c24;
    }

    /* Button Secondary */
    .btn-secondary {
        background: #6c757d;
        border: none;
        padding: 0.6rem 1.5rem;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-secondary:hover {
        background: #5a6268;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(108, 117, 125, 0.3);
    }

    /* Button Warning */
    .btn-warning {
        background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
        border: none;
        color: white;
        padding: 0.7rem 1.5rem;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 12px rgba(255, 193, 7, 0.3);
    }

    .btn-warning:hover {
        background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(255, 193, 7, 0.4);
    }

    /* Card Custom Enhancement */
    .card.card-custom .card-header.card-header-custom h6 {
        font-weight: 700;
        color: white;
    }

    /* Small Text */
    small.form-text {
        color: #6c757d;
        font-style: italic;
    }

    /* Responsive */
    @media (max-width: 767px) {
        .d-flex.justify-content-between {
            flex-direction: column;
            gap: 1rem;
        }

        .btn-secondary, .btn.btn-primary-custom {
            width: 100%;
        }

        .form-control {
            font-size: 0.9rem;
        }

        h6.text-muted {
            font-size: 1rem;
        }
    }
</style>
@endsection
